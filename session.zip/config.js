module.exports = {

    //Database Redis
    DIR_ROOT: __dirname
};
