$(document).ready(function() {



    $('button').click(function(event) {
      // creer une session pour acceder au username
      // réagire au clic en ajoutant la video (id) dans la bdd
      // sous le username
      // dans favoris.html faire s'afficher la liste des videos


});
